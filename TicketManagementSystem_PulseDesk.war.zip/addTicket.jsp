<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ page import="com.ticketmanagement.util.Html" %>
<%
    String ticketId = request.getParameter("id");
    boolean created = "1".equals(request.getParameter("created"));
%>
<!DOCTYPE html>
<html lang="en">
<head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>Ticket saved | PulseDesk</title><link rel="stylesheet" href="assets/css/app.css"></head>
<body class="app-page">
  <jsp:include page="/NavigationServlet" />
  <main class="page-shell">
    <section class="success-panel panel">
      <div class="success-mark">✓</div>
      <span class="kicker">TICKET INTAKE / COMPLETE</span>
      <% if (created) { %>
        <h2>Your ticket is in the queue.</h2>
        <p>The new ticket was saved successfully. You can open it in the ticket list to review or update it.</p>
        <div class="generated-id">TICKET #<%= Html.escape(ticketId) %></div>
      <% } else { %>
        <h2>Ticket intake</h2><p>Use the create form to add a new request to the queue.</p>
      <% } %>
      <div class="confirm-actions"><a class="btn btn-primary" href="ViewTicketServlet">View ticket queue →</a><a class="btn btn-soft" href="addTicketForm.html">Create another</a></div>
    </section>
  </main>
</body>
</html>
