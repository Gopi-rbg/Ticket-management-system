<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ page import="java.util.Map" %>
<%
    Map<String, Integer> counts = (Map<String, Integer>) request.getAttribute("counts");
    int total = counts == null ? 0 : counts.getOrDefault("total", 0);
    int open = counts == null ? 0 : counts.getOrDefault("open", 0);
    int progress = counts == null ? 0 : counts.getOrDefault("progress", 0);
    int resolved = counts == null ? 0 : counts.getOrDefault("resolved", 0);
    String roll = String.valueOf(session.getAttribute("rollNumber"));
%>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Overview | PulseDesk</title><link rel="stylesheet" href="assets/css/app.css">
</head>
<body class="app-page">
  <jsp:include page="/NavigationServlet" />
  <main class="page-shell">
    <section class="hero-panel panel">
      <div class="hero-copy">
        <span class="hero-label"><span class="hint-dot"></span> WORKSPACE / LIVE OVERVIEW</span>
        <h1>Move work<br><span>forward.</span></h1>
        <p>Welcome back, <strong><%= roll %></strong>. Keep requests visible, give every ticket an owner and make progress easy to follow.</p>
        <div class="hero-actions"><a class="btn btn-primary" href="addTicketForm.html">＋ Create a ticket</a><a class="btn btn-soft" href="ViewTicketServlet">Open ticket queue <span>→</span></a></div>
      </div>
      <div class="hero-visual"><div class="orbit"><div class="orbit-core">P</div></div><div class="orbit-tag">TRACK · ASSIGN · RESOLVE</div></div>
    </section>

    <div class="section-row"><div><span class="kicker">LIVE SIGNALS</span><h2>Workspace pulse</h2></div><p>Current ticket counts from TicketDB</p></div>
    <section class="stats-grid">
      <article class="stat-card stat-mint"><div class="stat-label">Total tickets</div><div class="stat-value"><%= total %></div><div class="stat-note">All recorded requests</div></article>
      <article class="stat-card stat-orange"><div class="stat-label">Open</div><div class="stat-value"><%= open %></div><div class="stat-note">Waiting for action</div></article>
      <article class="stat-card stat-blue"><div class="stat-label">In progress</div><div class="stat-value"><%= progress %></div><div class="stat-note">Currently being handled</div></article>
      <article class="stat-card stat-red"><div class="stat-label">Resolved</div><div class="stat-value"><%= resolved %></div><div class="stat-note">Completed requests</div></article>
    </section>

    <div class="section-row"><div><span class="kicker">WORKSPACE TOOLS</span><h2>Choose your next action</h2></div></div>
    <section class="quick-grid">
      <a class="quick-card" href="addTicketForm.html"><div class="quick-icon">＋</div><h3>Create a ticket</h3><p>Record a new issue and assign its priority.</p><span class="quick-arrow">↗</span></a>
      <a class="quick-card" href="ViewTicketServlet"><div class="quick-icon">▤</div><h3>View all tickets</h3><p>Review the queue, edit details or remove a record.</p><span class="quick-arrow">↗</span></a>
      <a class="quick-card" href="updateTicketForm.html"><div class="quick-icon">↻</div><h3>Quick update</h3><p>Change a ticket when you already know its ID.</p><span class="quick-arrow">↗</span></a>
    </section>
    <div class="bottom-strip"><span><strong>TIP /</strong> Keep ticket titles short and specific.</span><span>Signed in as <strong><%= roll %></strong> · Session protected</span></div>
  </main>
</body>
</html>
