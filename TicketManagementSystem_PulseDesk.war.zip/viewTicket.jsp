<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ page import="java.util.List,java.util.Map,com.ticketmanagement.model.Ticket,com.ticketmanagement.util.Html" %>
<%
    List<Ticket> tickets = (List<Ticket>) request.getAttribute("tickets");
    Map<String, Integer> counts = (Map<String, Integer>) request.getAttribute("counts");
    int total = counts == null ? 0 : counts.getOrDefault("total", 0);
    String ctx = request.getContextPath();
%>
<!DOCTYPE html>
<html lang="en">
<head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>All tickets | PulseDesk</title><link rel="stylesheet" href="assets/css/app.css"></head>
<body class="app-page">
  <jsp:include page="/NavigationServlet" />
  <main class="page-shell">
    <div class="page-heading"><div><span class="kicker">TICKET QUEUE / RECORDS</span><h1>All <span class="accent">tickets.</span></h1><p>Review, edit and manage every issue recorded in the system.</p></div><a class="btn btn-primary" href="addTicketForm.html">＋ New ticket</a></div>
    <% if ("1".equals(request.getParameter("updated"))) { %><div class="notice notice-success">Ticket details updated.</div><% } %>
    <% if ("1".equals(request.getParameter("deleted"))) { %><div class="notice notice-success">Ticket deleted successfully.</div><% } %>
    <% if ("0".equals(request.getParameter("deleted"))) { %><div class="notice notice-error">No ticket was deleted. It may already have been removed.</div><% } %>
    <% if ("1".equals(request.getParameter("missing"))) { %><div class="notice notice-error">Ticket ID was not found.</div><% } %>
    <section class="panel table-panel">
      <div class="table-top"><div><h2>Ticket register</h2><p>Latest tickets appear first. Use Edit or Delete to manage a record.</p></div><span class="table-count"><%= total %> RECORDS</span></div>
      <div class="table-wrap">
        <table class="ticket-table">
          <thead><tr><th>Ticket</th><th>Priority</th><th>Status</th><th>Assigned to</th><th>Actions</th></tr></thead>
          <tbody>
          <% if (tickets == null || tickets.isEmpty()) { %>
            <tr><td colspan="5"><div class="empty-state"><div class="empty-mark">＋</div><h3>No tickets yet</h3><p>Create the first ticket to start tracking work.</p><a class="btn btn-primary" href="addTicketForm.html">Create first ticket</a></div></td></tr>
          <% } else { for (Ticket ticket : tickets) {
              String priority = ticket.getPriority() == null ? "Medium" : ticket.getPriority();
              String status = ticket.getStatus() == null ? "Open" : ticket.getStatus();
              String pClass = "priority-" + priority.toLowerCase();
              String sClass = "status-" + status.toLowerCase().replace(" ", "-");
          %>
            <tr>
              <td><span class="ticket-id">#<%= ticket.getTicketId() %></span><strong class="ticket-title"><%= Html.escape(ticket.getTitle()) %></strong><span class="ticket-desc"><%= Html.escape(ticket.getDescription()) %></span></td>
              <td><span class="pill <%= pClass %>"><%= Html.escape(priority) %></span></td>
              <td><span class="pill <%= sClass %>"><%= Html.escape(status) %></span></td>
              <td><span class="owner"><%= ticket.getAssignedToName() == null ? "Unassigned" : Html.escape(ticket.getAssignedToName()) %></span><% if (ticket.getAssignedTo()!=null) { %><small>#<%= ticket.getAssignedTo() %></small><% } %></td>
              <td><div class="row-actions"><a class="row-action row-edit" href="<%= ctx %>/UpdateTicketServlet?id=<%= ticket.getTicketId() %>">Edit</a><a class="row-action row-delete" href="<%= ctx %>/DeleteTicketServlet?id=<%= ticket.getTicketId() %>">Delete</a></div></td>
            </tr>
          <% } } %>
          </tbody>
        </table>
      </div>
    </section>
  </main>
</body>
</html>
