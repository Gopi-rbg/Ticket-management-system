document.addEventListener('DOMContentLoaded', function () {
  const navHost = document.querySelector('[data-nav]');
  if (navHost) {
    fetch('NavigationServlet', { credentials: 'same-origin' })
      .then(response => {
        if (!response.ok) throw new Error('Navigation unavailable');
        return response.text();
      })
      .then(html => {
        navHost.innerHTML = html;
        const toggle = navHost.querySelector('.nav-toggle');
        const links = navHost.querySelector('.nav-links');
        if (toggle && links) toggle.addEventListener('click', () => links.classList.toggle('nav-open'));
      })
      .catch(() => { navHost.innerHTML = '<div class="nav-fallback">PulseDesk</div>'; });
  }
});
