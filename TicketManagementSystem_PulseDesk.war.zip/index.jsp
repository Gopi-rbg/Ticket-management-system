<%@ page contentType="text/html; charset=UTF-8" %>
<%
    if (session != null && session.getAttribute("rollNumber") != null) {
        response.sendRedirect(request.getContextPath() + "/HomeServlet");
    } else {
        response.sendRedirect(request.getContextPath() + "/login.html");
    }
%>
