<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ page import="com.ticketmanagement.model.Ticket,com.ticketmanagement.util.Html" %>
<%
    Ticket ticket = (Ticket) request.getAttribute("ticket");
    String ctx = request.getContextPath();
%>
<!DOCTYPE html>
<html lang="en">
<head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>Delete ticket | PulseDesk</title><link rel="stylesheet" href="assets/css/app.css"></head>
<body class="app-page">
  <jsp:include page="/NavigationServlet" />
  <main class="page-shell">
    <section class="confirm-panel panel">
      <div class="confirm-mark">!</div><span class="kicker">TICKET CONTROL / DELETE</span>
      <h2>Remove this ticket?</h2>
      <p>This action permanently deletes the selected ticket record. The employee record will not be affected.</p>
      <div class="confirm-ticket"><small>SELECTED TICKET · #<%= ticket.getTicketId() %></small><strong><%= Html.escape(ticket.getTitle()) %></strong><p><%= Html.escape(ticket.getDescription()) %></p></div>
      <form action="<%= ctx %>/DeleteTicketServlet" method="post" class="confirm-actions"><input type="hidden" name="ticket_id" value="<%= ticket.getTicketId() %>"><button class="btn" style="background:#ff7f86;color:#1d1720" type="submit">Yes, delete ticket</button><a class="btn btn-soft" href="ViewTicketServlet">Keep ticket</a></form>
    </section>
  </main>
</body>
</html>
