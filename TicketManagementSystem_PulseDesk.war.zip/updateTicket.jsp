<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ page import="java.util.List,com.ticketmanagement.model.Ticket,com.ticketmanagement.model.Employee,com.ticketmanagement.util.Html" %>
<%
    Ticket ticket = (Ticket) request.getAttribute("ticket");
    List<Employee> employees = (List<Employee>) request.getAttribute("employees");
    String ctx = request.getContextPath();
%>
<!DOCTYPE html>
<html lang="en">
<head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>Edit ticket | PulseDesk</title><link rel="stylesheet" href="assets/css/app.css"></head>
<body class="app-page">
  <jsp:include page="/NavigationServlet" />
  <main class="page-shell">
    <div class="page-heading"><div><span class="kicker">TICKET CONTROL / EDIT #<%= ticket.getTicketId() %></span><h1>Refine the <span class="accent">details.</span></h1><p>Update the ticket and save the latest information.</p></div><a class="btn btn-soft" href="ViewTicketServlet">← Back to queue</a></div>
    <section class="panel form-panel compact-form">
      <div class="panel-heading"><div class="panel-icon">↻</div><div><h2>Update ticket #<%= ticket.getTicketId() %></h2><p>Changes are saved to the Ticket table.</p></div></div>
      <form action="<%= ctx %>/UpdateTicketServlet" method="post" class="ticket-form">
        <input type="hidden" name="ticket_id" value="<%= ticket.getTicketId() %>">
        <div class="field field-wide"><label for="title">Ticket title <em>*</em></label><input id="title" name="title" value="<%= Html.escape(ticket.getTitle()) %>" maxlength="255" required></div>
        <div class="field field-wide"><label for="description">Description</label><textarea id="description" name="description" rows="5"><%= Html.escape(ticket.getDescription()) %></textarea></div>
        <div class="field"><label for="priority">Priority</label><select id="priority" name="priority">
          <% String[] priorities={"Low","Medium","High","Critical"}; for(String item:priorities) { %><option value="<%= item %>" <%= item.equals(ticket.getPriority())?"selected":"" %>><%= item %></option><% } %>
        </select></div>
        <div class="field"><label for="status">Status</label><select id="status" name="status">
          <% String[] statuses={"Open","In Progress","Resolved","Closed"}; for(String item:statuses) { %><option value="<%= item %>" <%= item.equals(ticket.getStatus())?"selected":"" %>><%= item %></option><% } %>
        </select></div>
        <div class="field field-wide"><label for="assigned_to">Assigned employee <span class="optional">OPTIONAL</span></label><select id="assigned_to" name="assigned_to"><option value="">Unassigned</option>
          <% if (employees != null) for(Employee employee:employees) { %><option value="<%= employee.getEmployeeId() %>" <%= ticket.getAssignedTo()!=null && ticket.getAssignedTo()==employee.getEmployeeId()?"selected":"" %>>#<%= employee.getEmployeeId() %> — <%= Html.escape(employee.getEmployeeName()) %> · <%= Html.escape(employee.getDepartment()) %></option><% } %>
        </select></div>
        <div class="form-actions field-wide"><button class="btn btn-primary" type="submit">Save ticket changes →</button><a class="btn btn-quiet" href="ViewTicketServlet">Cancel</a></div>
      </form>
    </section>
  </main>
</body>
</html>
